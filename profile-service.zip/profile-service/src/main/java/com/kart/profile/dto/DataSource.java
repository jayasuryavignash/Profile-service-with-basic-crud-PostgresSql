package com.kart.profile.dto;

import io.swagger.models.auth.In;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DataSource {
  private String documentBaseUrl;
  private String placesBaseUrl;
  private String profileServiceBaseUrl;
  private String profileWebappBaseUrl;
  private String messagingServiceUrl;
  private String fromEmail;
  private String customerChannel;
  private String goomoUrl;
  private String b2bCustomerApi;
  private String keycloakMasterRealm;
  private String keycloakRealm;
  private String keycloakUrl;
  private String clientSecret;
  private String clientId;
  private String keycloakDBRealm;
  private String phoneVerificationMessageId;
  private String emailVerificationMessageId;
  private String importUserMessageId;
  private String storeServiceUrl;
  private String loginDetailMessageId;
  private String adminKeycloakRealm;
  private String adminKeycloakUrl;
  private String commonServiceBaseUrl;
}

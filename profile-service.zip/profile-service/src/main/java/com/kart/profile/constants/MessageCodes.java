package com.kart.profile.constants;

public class MessageCodes {

    public static final String SUCCESS = "200";
    public static final String CREATE = "201";
    public static final Integer CREATED = 201;
    public static final Integer OK = 200;
    public static final Integer BAD_REQUESTS = 400;
    public static final String SUCCESS_MSG = "SUCCESS";
    public static final String SUCCESS_DESC = "Request processed successfully";

    public static final String SIGNIN_SUCCESS = "SignIn successful";

    public static final String NO_INFO_AVAILABLE = "No info available";

    public static final Integer NOT_FOUND = 404;
    public static final Integer NO_CONTENT = 204;

    public static final String NON_AUTHORATIVE_INFORMATION = "203";
    public static final String NON_AUTHORATIVE_INFORMATION_MSG = "Non Authorative Response";
    public static final String NON_AUTHORATIVE_INFORMATION_DESC = "Non Authorative Response Error. Please try again later";

    public static final String INTERNAL_SERVER_ERROR = "500";
    public static final String INTERNAL_SERVER_ERROR_MSG = "Internal Server Error";
    public static final String INTERNAL_SERVER_ERROR_DESC = "Internal Server Error. Please try again later.";

    public static final String BAD_REQUEST = "400";
    public static final String BAD_REQUEST_MSG = "BAD_REQUEST";
    public static final String BAD_REQUEST_DESC = "Invalid Request. Please provide valid request.";

    public static final String UN_AUTHORISATION = "401";
    public static final String UNAUTHORISED_MSG = "Unauthorised";
    public static final String UNAUTHORISED_DESC = "Unauthorised. Access Denied";

    public static final String FORBIDDEN = "403";
    public static final String FORBIDDEN_MSG = "Forbidden";
    public static final String FORBIDDEN_DESC = "Forbidden. Access Denied";

    public static final String HEALTH_CHECK_RES_DESC = "Health check successful";

    public static final String COUNTRY_CODE_MANDATORY = "Country Code is mandatory";
    public static final String EMAIL_ID_MANDATORY = "Email id is mandatory";
    public static final String PHONE_NUMBER_MANDATORY = "Phone number is mandatory";
    public static final String USERID_MANDATORY = "User id is mandatory";
    public static final String USER_NAME_MANDATORY = "Email or phone number should be passed to sign in";
    public static final String TOKEN_MANDATORY = "Token is mandatory";
    public static final String PASSWORD_MANDATORY = "Password is mandatory";
    public static final String CONFIRM_PASSWORD_MANDATORY = "Confirm password is mandatory";
    public static final String PASSWORD_CHANGED = "Password changed successfully";
    public static final String INCORRECT_PASSWORD = "Password is incorrect";
    public static final String USER_DOES_NOT_EXISTS = "User does not exists";
    public static final String PASSWORD_MISMATCH = "Password is mismatch";
    public static final String USER_NOT_REGISTERED = "User is not registered.Please register";
    public static final String ADD_PHONE_NUMBER = "Please add phone number";

    public static final String OTP_SEND_SUCCESSFULLY = "Otp is send successfully";
    public static final String INVALID_OTP = "Otp is not valid, please enter valid otp";
    public static final String INVALID_TOKEN = "Email token is invalid";
    public static final String INVALID_EMAIL_ID = "Invalid email id";
    public static final String INVALID_PHONE_NUMBER = "Phone number is not valid";
    public static final String INVALID_TYPE = "Type is not valid";
    public static final String INVALID_USER_ID = "Invalid user id";
    public static final String EMAIL_ID_ALREADY_EXISTS = "Email id already exists";
    public static final String PHONE_NUMBER_ALREADY_EXISTS = "Phone number already exists";
    public static final String PHONE_NUMBER_NOT_VERIFIED = "Phone number is not verified";
    public static final String PHONE_NUMBER_ALREADY_VERIFIED = "Phone number is already verified";
    public static final String EMAIL_ID_ALREADY_VERIFIED = "Email is already verified";
    public static final String USER_ALREADY_EXISTS = "User already exists";
    public static final String INVALID_DATE_FORMAT = "Invalid date format";
    public static final String INVALID_PAYBACK_POINT_STATUS = "Invalid opt payback points status";

    public static final String ACCOUNT_LOCKED = "Account is locked";

    public static final String MANDATORY_FIRST_NAME = "User first name is mandatory";
    public static final String MANDATORY_LAST_NAME = "User last name is mandatory";
    public static final String MANDATORY_ADDRESS = "User address is mandatory";
    public static final String INVALID_PAGENO_OR_PAGESIZE = "Invalid Page no or page size";
    public static final String INVALID_STATUS = "Invalid status";

    public static final String SYMBOL_PLUS = "+";
    public static final Boolean TRUE = true;
    public static final String DEFAULT_COUNTRY_CODE = "+91";

}

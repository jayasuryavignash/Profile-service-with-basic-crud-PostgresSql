package com.kart.profile.mapper;

import com.kart.profile.dto.*;
import com.kart.profile.model.UserProfile;
import com.kart.profile.utils.CommonUtil;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor
public class ResponseMapper {

  public UserProfileDTO convert(
      UserProfile userProfile, UserProfileDTO response) {
    log.debug("Started converting UserProfile to UserProfileDTO");
    response.setUserId(userProfile.getUserId());
    response.setTitle(userProfile.getTitle());
    response.setFirstName(userProfile.getFirstName());
    response.setLastName(userProfile.getLastName());
    response.setPhoneNumber(userProfile.getPhoneNumber());
    response.setCountryCode(userProfile.getCountryCode());
    response.setUserStatus(userProfile.getProfileStatus());
    if (!CommonUtil.checkIsNullOrEmpty(userProfile.getMiddleName()))
      response.setMiddleName(userProfile.getMiddleName());
    if (!CommonUtil.checkIsNullOrEmpty(userProfile.getGender()))
      response.setGender(userProfile.getGender());
    if (!CommonUtil.checkIsNullOrEmpty(userProfile.getEmail()))
      response.setEmail(userProfile.getEmail());
    if (!CommonUtil.checkIsNull(userProfile.getDateOfBirth()))
      response.setDateOfBirth(userProfile.getDateOfBirth());
    if (!CommonUtil.checkIsNullOrEmpty(userProfile.getNationality()))
      response.setNationality(userProfile.getNationality());
    log.debug("Completed converting UserProfile to UserProfileDTO");
    return response;
  }

  public Meta createPaginationResponse(int page, int size, long recordCount) {
    log.debug("create Meta by populating all attributes");
    int pagesCount = (int) Math.ceil((double) recordCount / size);
    Meta meta =
        Meta.builder()
            .pagination(
                Pagination.builder()
                    .currentPage(page)
                    .perPage(size)
                    .totalPages(pagesCount)
                    .totalObjects(recordCount)
                    .build())
            .build();
    return meta;
  }
}

package com.kart.profile.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class Meta {

	private Pagination pagination;
	private String authenticationToken;

}

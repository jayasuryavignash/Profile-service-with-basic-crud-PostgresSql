package com.kart.profile.dto.request;

import lombok.*;

import java.io.Serializable;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddressRequest implements Serializable {

	private static final long serialVersionUID = -2638827195770279274L;
	private Integer priority;
	private String addressType;
	private String addressLine1;
	private String addressLine2;
	private String locality;
	private String landmark;
	private String postalCode;
	private String phoneNumber;
	private String geoLocation;
	private String country;
	private String state;
	private String city;
}

package com.kart.profile.enums;

import com.kart.profile.constants.MessageCodes;
import com.kart.profile.utils.CommonUtil;

public enum ProfileStatus {
  Active(1),
  InActive(2);

  int profileStatus;

  ProfileStatus(int profileStatus) {
    this.profileStatus = profileStatus;
  }

  public int getValue() {
    return profileStatus;
  }

  public static ProfileStatus getStatus(int profileStatus) {
    ProfileStatus profileStatus1 = null; // Default
    for (ProfileStatus item : ProfileStatus.values()) {
      if (item.getValue() == profileStatus) {
        profileStatus1 = item;
        break;
      }
    }
    if (CommonUtil.checkIsNull(profileStatus1)) {
      throw new IllegalArgumentException(MessageCodes.INVALID_STATUS);
    }
    return profileStatus1;
  }
}

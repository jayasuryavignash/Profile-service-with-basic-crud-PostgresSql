package com.kart.profile.dto.response;

public class AddressReponse {
}

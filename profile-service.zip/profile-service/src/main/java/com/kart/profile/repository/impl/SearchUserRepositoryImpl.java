package com.kart.profile.repository.impl;

import com.kart.profile.model.UserProfile;
import com.kart.profile.repository.SearchUserRepository;
import com.kart.profile.utils.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class SearchUserRepositoryImpl implements SearchUserRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<UserProfile> searchUser(Pageable pageable, String firstName, String phoneNumber, String lastName, String createdBy) {
        log.info("get users with firstName - " + firstName + " createdBy - " + createdBy + " phoneNumber - "
                + phoneNumber + " lastName - " + lastName);
        List<UserProfile> profiles = null;
        String selectQuery =
                "select u.user_id, u.title, u.first_name, u.middle_name, u.last_name,u.description,u.nationality,u.phone_number, u.gender, u.date_of_birth, u.status, u.email, u.country_code, u.created_at,u.updated_at,u.created_by,u.updated_by from user_profile u ";
        Map<String, Object> paramMap = new HashMap<>();
        StringBuilder query = gettWhereClause(paramMap, firstName, createdBy, phoneNumber, lastName);
        javax.persistence.Query result = entityManager.createNativeQuery(selectQuery + query.toString(),
                UserProfile.class);
        for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
            result.setParameter(entry.getKey(), entry.getValue());
        }
        profiles = result.setFirstResult((int) pageable.getOffset()).setMaxResults(pageable.getPageSize()).getResultList();
        log.info("get users completed");
        return profiles;
    }

    @Override
    public long countUserBasedOnsearch(Pageable pageable, String firstName, String phoneNumber, String lastName, String createdBy) {
        long noOfRecord = 0;
        String selectQuery =
                "select u.user_id, u.title, u.first_name, u.middle_name, u.last_name,u.description,u.nationality,u.phone_number, u.gender, u.date_of_birth, u.status, u.email, u.country_code, u.created_at,u.updated_at,u.created_by,u.updated_by from user_profile u ";
        Map<String, Object> paramMap = new HashMap<>();
        StringBuilder query = gettWhereClause(paramMap, firstName, createdBy, phoneNumber, lastName);
        javax.persistence.Query result = entityManager.createNativeQuery(selectQuery + query.toString(),
                UserProfile.class);
        for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
            result.setParameter(entry.getKey(), entry.getValue());
        }
        noOfRecord = result.getResultList().size();
//        noOfRecord = Long.valueOf(result.getSingleResult().toString());
        return noOfRecord;
    }

    private StringBuilder gettWhereClause(Map<String, Object> paramMap, String firstName, String createdBy, String phoneNumber, String lastName) {
        StringBuilder query = new StringBuilder();
        boolean whereAdded = false;
        if (!CommonUtil.checkIsNullOrEmpty(firstName) && !CommonUtil.checkIsNullOrEmpty(phoneNumber)) {
            if (whereAdded) {
                query.append(" and ");
            } else {
                whereAdded = true;
                query.append(" where ");
            }
            query.append(" (lower(u.first_name) like lower(:firstName) and u.phone_number like :phoneNumber) ");
            paramMap.put("firstName", "%" + firstName + "%");
            paramMap.put("phoneNumber", "%" + phoneNumber + "%");
        } else {
            if (!CommonUtil.checkIsNullOrEmpty(firstName)) {
                if (whereAdded) {
                    query.append(" and ");
                } else {
                    whereAdded = true;
                    query.append(" where ");
                }
                query.append(" lower(u.first_name) like lower(:firstName)");
                paramMap.put("firstName", "%" + firstName + "%");
            }
            if (!CommonUtil.checkIsNullOrEmpty(phoneNumber)) {
                if (whereAdded) {
                    query.append(" and ");
                } else {
                    whereAdded = true;
                    query.append(" where ");
                }
                query.append(" u.phone_number like :phoneNumber");
                paramMap.put("phoneNumber", "%" + phoneNumber + "%");
            }
        }
        if (!CommonUtil.checkIsNullOrEmpty(lastName)) {
            if (whereAdded) {
                query.append(" and ");
            } else {
                whereAdded = true;
                query.append(" where ");
            }
            query.append(" lower(u.last_name) like lower(:lastName)");
            paramMap.put("lastName", "%" + lastName + "%");
        }
        if (!CommonUtil.checkIsNullOrEmpty(createdBy)) {
            if (whereAdded) {
                query.append(" and ");
            } else {
                whereAdded = true;
                query.append(" where ");
            }
            query.append(" lower(u.created_by) like lower(:createdBy)");
            paramMap.put("createdBy", "%" + createdBy + "%");
        }
        return query;
    }


}

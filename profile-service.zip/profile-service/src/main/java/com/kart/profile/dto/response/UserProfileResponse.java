package com.kart.profile.dto.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class UserProfileResponse extends BaseResponseModel {

	private static final long serialVersionUID = -2429276140687981093L;

	private String userId;
	private String title;
	private String firstName;
	private String middleName;
	private String lastName;
	private String gender;
	private Date dateOfBirth;
	private String nationality;
	private String status;
	private String description;
	private String phoneNumber;
	private String countryCode;
	private String email;
	private String createdBy;
	private String updatedBy;
	private List<AddressReponse> addresses;

	public void add(AddressReponse address) {
		if (addresses == null)
			addresses = new ArrayList<>();
		addresses.add(address);
	}
}

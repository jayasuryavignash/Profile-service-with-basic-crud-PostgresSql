package com.kart.profile.config;

import com.kart.profile.constants.APPConstants;
import com.kart.profile.dto.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
@Slf4j
public class DataSourceConfig {

    @Value("${spring.profiles.active}")
    private String domain;

    @Value("${common.service.baseurl}")
    private String commonServiceBaseURL;

    @Bean
    public synchronized DataSource getDataSource() {
        /*
         * if domain type is dev -> read from property file. If domain type is prod,
         * read from system environment.
         */
        log.info("domain type : " + domain);
        DataSource dataSourceModel = null;
        if (domain != null && !domain.isEmpty()
                && (domain.equalsIgnoreCase("dev") || domain.equalsIgnoreCase("test"))) {
            dataSourceModel = getDevelopmentDataSource();
        } else {
            dataSourceModel = getProductionDataSource();
        }
        return dataSourceModel;
    }

    private DataSource getProductionDataSource() {
        DataSource values = new DataSource();
        Map<String, String> env = System.getenv();
        values.setCommonServiceBaseUrl(env.get(APPConstants.COMMON_SERVICE_BASE_URL));
        return values;
    }

    private DataSource getDevelopmentDataSource() {
        DataSource values = new DataSource();
        values.setCommonServiceBaseUrl(commonServiceBaseURL);
        return values;
    }
}

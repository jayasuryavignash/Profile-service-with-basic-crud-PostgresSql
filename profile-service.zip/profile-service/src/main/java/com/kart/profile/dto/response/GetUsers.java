package com.kart.profile.dto.response;


import com.kart.profile.dto.Meta;
import com.kart.profile.dto.UserProfileDTO;
import com.kart.profile.model.UserProfile;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class GetUsers extends BaseResponseModel{

    private Meta meta;
    private List<UserProfileDTO> users;
}

package com.kart.profile.enums;

public enum MembershipStatus {

	NonGoomoAdvantageUser(0), Registered(1), Confirmed(2), Activated(3), Expired(4), Deactivated(5);

	int status;

	MembershipStatus(int status) {
		this.status = status;
	}

	public int getValue() {
		return status;
	}

	public static MembershipStatus getStatus(int status) {
		MembershipStatus advantageStatus = null; // Default
		for (MembershipStatus item : MembershipStatus.values()) {
			if (item.getValue() == status) {
				advantageStatus = item;
				break;
			}
		}
		return advantageStatus;

	}
}

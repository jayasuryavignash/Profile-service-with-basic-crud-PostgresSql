package com.kart.profile.service.impl;

import com.kart.profile.config.DataSourceConfig;
import com.kart.profile.constants.MessageCodes;
import com.kart.profile.dao.UserDAO;
import com.kart.profile.dto.UserProfileDTO;
import com.kart.profile.dto.response.*;
import com.kart.profile.enums.ProfileStatus;
import com.kart.profile.mapper.RequestMapper;
import com.kart.profile.mapper.ResponseMapper;
import com.kart.profile.model.UserProfile;
import com.kart.profile.service.UserService;
import com.kart.profile.utils.CommonUtil;
import com.kart.profile.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

  private UserDAO userDAO;
  private DataSourceConfig dataSourceConfig;
  private static Double balance = 500.0;

  @Autowired
  public UserServiceImpl(UserDAO userDAO, DataSourceConfig dataSourceConfig) {
    this.userDAO = userDAO;
    this.dataSourceConfig = dataSourceConfig;
    userUtil = new UserUtil(userDAO);
    requestMapper = new RequestMapper(userUtil);
    responseMapper = new ResponseMapper();
  }

  private static UserUtil userUtil;
  private static RequestMapper requestMapper;
  private static ResponseMapper responseMapper;
  private static StatusMessage statusMessage = new StatusMessage();
  private static BaseResponseModel response = new BaseResponseModel();

  @Override
  public UserProfileDTO createUser(UserProfileDTO profileRequest) {
    log.info("Create a new user profile with given details - " + profileRequest);
    UserProfileDTO response = new UserProfileDTO();
    if (UserUtil.validate(profileRequest)) {
      UserProfile userProfile = new UserProfile();
      userProfile = userDAO.getUserProfileByPhoneNumber(profileRequest.getPhoneNumber());
      if (userProfile != null) {
        log.error("User already exists");
        throw new IllegalArgumentException(MessageCodes.USER_ALREADY_EXISTS);
      }
      // TO DO check for Drools for referel amount
      userProfile = requestMapper.convert(profileRequest, balance);
      userProfile = userDAO.save(userProfile);
      response = (UserProfileDTO) responseMapper.convert(userProfile, response);
    }
    response.setStatus(MessageCodes.SUCCESS);
    statusMessage.setCode(MessageCodes.SUCCESS_MSG);
    statusMessage.setDescription(MessageCodes.SUCCESS_DESC);
    response.setStatusMessage(statusMessage);
    return response;
  }

  @Override
  public UserProfileDTO updateUser(String id, UserProfileDTO profileRequest) {
    log.info("Update a new customer profile with given details - " + profileRequest);
    UserProfileDTO response = new UserProfileDTO();
    UserProfile userProfile = userUtil.validateUser(id);
    userProfile = requestMapper.convert(profileRequest, userProfile);
    userProfile = userDAO.save(userProfile);
    response = (UserProfileDTO) responseMapper.convert(userProfile, response);
    response.setStatus(MessageCodes.SUCCESS);
    statusMessage.setCode(MessageCodes.SUCCESS_MSG);
    statusMessage.setDescription(MessageCodes.SUCCESS_DESC);
    response.setStatusMessage(statusMessage);
    return response;
  }

  @Override
  public UserProfileDTO getUserProfile(String id) {
    log.debug("Getting User Profile started with id " + id);
    UserProfile userProfile = userUtil.validateUser(id);
    UserProfileDTO profile =
        (UserProfileDTO) responseMapper.convert(userProfile, new UserProfileDTO());
    profile.setStatus(MessageCodes.SUCCESS);
    statusMessage.setCode(MessageCodes.SUCCESS_MSG);
    statusMessage.setDescription(MessageCodes.SUCCESS_DESC);
    profile.setStatusMessage(statusMessage);
    return profile;
  }

  @Override
  public BaseResponseModel deleteUser(String id) {
    log.debug("Delete User Profile started");
    UserProfile userProfile = userUtil.validateUser(id);
    userProfile.setProfileStatus(ProfileStatus.InActive);
    userDAO.save(userProfile);
    response.setStatus(MessageCodes.SUCCESS);
    statusMessage.setCode(MessageCodes.SUCCESS_MSG);
    statusMessage.setDescription(MessageCodes.SUCCESS_DESC);
    response.setStatusMessage(statusMessage);
    return response;
  }

  @Override
  public GetUsers getUsers(
      String firstName,
      String phoneNumber,
      String lastName,
      String createdBy,
      int currentPage,
      int perPage) {
    log.info("Get All Users ");
    CommonUtil.checkPaginationParameters(currentPage, perPage);
    Pageable pageable = PageRequest.of(currentPage - 1, perPage);
    GetUsers response = new GetUsers();
    long recordCount = 0;
    List<UserProfileDTO> profileDTOS = new ArrayList<>();
    List<UserProfile> profiles =
        userDAO.searchUser(pageable, firstName, phoneNumber, lastName, createdBy);
    if (!CommonUtil.checkIsNullOrEmpty(profiles)) {
      recordCount =
          userDAO.countOfSearchUser(pageable, firstName, phoneNumber, lastName, createdBy);
      for (UserProfile profile : profiles) {
        profileDTOS.add(responseMapper.convert(profile, new UserProfileDTO()));
      }
      statusMessage.setDescription(MessageCodes.SUCCESS_DESC);
    } else {
      statusMessage.setDescription(MessageCodes.NO_INFO_AVAILABLE);
    }
    response.setMeta(responseMapper.createPaginationResponse(currentPage, perPage, recordCount));
    response.setUsers(profileDTOS);
    response.setStatus(MessageCodes.SUCCESS);
    statusMessage.setCode(MessageCodes.SUCCESS_MSG);
    response.setStatusMessage(statusMessage);
    log.info("Get All User Details :: Response ::" + response);
    return response;
  }
}

package com.kart.profile.dto;

import com.kart.profile.dto.request.AddressRequest;
import com.kart.profile.dto.response.BaseResponseModel;
import com.kart.profile.enums.ProfileStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserProfileDTO extends BaseResponseModel {

  private static final long serialVersionUID = 1L;
  private String title;
  private String firstName;
  private String middleName;
  private String lastName;
  private String gender;
  private Date dateOfBirth;
  private String nationality;
  private ProfileStatus userStatus;
  private String description;
  private String phoneNumber;
  private String countryCode;
  private String email;
  private String createdBy;
  private String updatedBy;
  private List<AddressRequest> addresses;
  private String referalCode;

  public void add(AddressRequest address) {
    if (addresses == null) addresses = new ArrayList<>();
    addresses.add(address);
  }
}

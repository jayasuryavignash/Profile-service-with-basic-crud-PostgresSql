package com.kart.profile.service;

import com.kart.profile.dto.UserProfileDTO;
import com.kart.profile.dto.response.BaseResponseModel;
import com.kart.profile.dto.response.GetUsers;

public interface UserService {

  UserProfileDTO createUser(UserProfileDTO profileRequest);

  UserProfileDTO updateUser(String id, UserProfileDTO profileRequest);

  UserProfileDTO getUserProfile(String id);

  BaseResponseModel deleteUser(String id);

  GetUsers getUsers(
      String firstName,
      String phoneNumber,
      String lastName,
      String createdBy,
      int currentPage,
      int perPage);
}

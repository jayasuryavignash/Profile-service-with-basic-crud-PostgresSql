package com.kart.profile.mapper;

import com.kart.profile.constants.MessageCodes;
import com.kart.profile.constants.SequencePrefix;
import com.kart.profile.dto.DataSource;
import com.kart.profile.dto.UserProfileDTO;
import com.kart.profile.enums.ProfileStatus;
import com.kart.profile.model.UserProfile;
import com.kart.profile.utils.CommonUtil;
import com.kart.profile.utils.UserUtil;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

@Slf4j
@NoArgsConstructor
public class RequestMapper {
    @Autowired
    DataSource dataSource;

    private UserUtil userUtil;

    public RequestMapper(UserUtil userUtil) {
        this.userUtil = userUtil;
    }

    public UserProfile convert(UserProfileDTO profileRequest, Double balance) {
        log.debug("Started converting UserProfileRequest to UserProfile");
        String userId = SequencePrefix.CUSTOMER_PROFILE_PREFIX.concat(CommonUtil.generateDigitUniqueId());
        UserProfile userProfile = UserProfile.builder()
                .userId(userId)
                .title(profileRequest.getTitle())
                .firstName(profileRequest.getFirstName())
                .middleName(CommonUtil.checkIsNullOrEmpty(profileRequest.getMiddleName())
                        ? null
                        : profileRequest.getMiddleName())
                .lastName(profileRequest.getLastName())
                .gender(CommonUtil.checkIsNullOrEmpty(profileRequest.getGender())
                        ? null
                        : profileRequest.getGender())
                .dateOfBirth(CommonUtil.checkIsNull(profileRequest.getDateOfBirth())
                        ? null
                        : profileRequest.getDateOfBirth())
                .nationality(CommonUtil.checkIsNullOrEmpty(profileRequest.getNationality())
                        ? null
                        : profileRequest.getNationality())
                .profileStatus(ProfileStatus.Active)
                .description(CommonUtil.checkIsNullOrEmpty(profileRequest.getDescription())
                        ? null
                        : profileRequest.getDescription())
                .createdBy(CommonUtil.checkIsNullOrEmpty(profileRequest.getCreatedBy())
                        ? profileRequest.getFirstName()
                        : profileRequest.getCreatedBy())
                .email(CommonUtil.checkIsNullOrEmpty(profileRequest.getEmail())
                        ? null
                        : profileRequest.getEmail())
                .countryCode(CommonUtil.checkIsNullOrEmpty(profileRequest.getCountryCode())
                        ? MessageCodes.DEFAULT_COUNTRY_CODE
                        : profileRequest.getCountryCode())
                .phoneNumber(profileRequest.getPhoneNumber())
                .updatedBy(profileRequest.getFirstName())
                .build();

        log.debug("Completed converting UserProfileRequest to UserProfile");
        return userProfile;
    }


    public UserProfile convert(UserProfileDTO profileRequest, UserProfile userProfile) {
        log.debug("Started converting profileRequest to UserProfile");
        if (profileRequest.getDateOfBirth() != null) {
            userProfile.setDateOfBirth(profileRequest.getDateOfBirth());
        }
        if (profileRequest.getDescription() != null) {
            userProfile.setDescription(profileRequest.getDescription());
        }
        if (profileRequest.getFirstName() != null) {
            userProfile.setFirstName(profileRequest.getFirstName());
        }
        if (profileRequest.getGender() != null) {
            userProfile.setGender(profileRequest.getGender());
        }
        if (profileRequest.getLastName() != null) {
            userProfile.setLastName(profileRequest.getLastName());
        }
        if (profileRequest.getMiddleName() != null) {
            userProfile.setMiddleName(profileRequest.getMiddleName());
        }
        if (profileRequest.getNationality() != null) {
            userProfile.setNationality(profileRequest.getNationality());
        }
        if (profileRequest.getPhoneNumber() != null) {
            userProfile.setPhoneNumber(profileRequest.getPhoneNumber());
        }
        if (profileRequest.getEmail() != null) {
            userProfile.setEmail(profileRequest.getEmail());
        }
        if (profileRequest.getCountryCode() != null) {
            userProfile.setCountryCode(profileRequest.getCountryCode());
        }
        if (profileRequest.getUpdatedBy() != null) {
            userProfile.setUpdatedBy(profileRequest.getUpdatedBy());
        }
        if (profileRequest.getTitle() != null) {
            userProfile.setTitle(profileRequest.getTitle());
        }
        if (profileRequest.getStatus() != null) {
            ProfileStatus status = profileRequest.getUserStatus().equals(ProfileStatus.Active) ? ProfileStatus.Active : ProfileStatus.InActive;
            userProfile.setProfileStatus(status);
        }
        userProfile.setUpdatedAt(new Date());
        log.debug("Completed converting profileRequest to UserProfile");
        return userProfile;
    }

}

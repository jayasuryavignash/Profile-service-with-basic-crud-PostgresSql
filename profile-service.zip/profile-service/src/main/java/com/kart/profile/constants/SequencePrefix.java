package com.kart.profile.constants;

public class SequencePrefix {

	public static final String CUSTOMER_PROFILE_PREFIX = "CP";
	public static final String CUSTOMER_CONTACT_PREFIX = "CC";
	public static final String EMERGENCY_CONTACT_PREFIX = "EC";
	public static final String CUSTOMER_ADDRESS_PREFIX = "CA";

	public static final String ADDRESS_TYPE_PREFIX = "AT";
	public static final String CUSTOMER_STATUS_PREFIX = "CS";
	public static final String CUSTOMER_TYPE_PREFIX = "CT";
	public static final String STATUS_PREFIX = "ST";


}

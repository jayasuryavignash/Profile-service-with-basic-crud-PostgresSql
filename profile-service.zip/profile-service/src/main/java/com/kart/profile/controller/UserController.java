package com.kart.profile.controller;

import com.kart.profile.constants.MessageCodes;
import com.kart.profile.constants.NameSpaceConstants;
import com.kart.profile.dto.UserProfileDTO;
import com.kart.profile.dto.response.BaseResponseModel;
import com.kart.profile.dto.response.GetUsers;
import com.kart.profile.dto.response.StatusMessage;
import com.kart.profile.service.UserService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = NameSpaceConstants.BASE_URL, produces = MediaType.APPLICATION_JSON_VALUE)
@Api(value = "User Service", produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
public class UserController {

  @Autowired private UserService userService;

  @GetMapping(value = NameSpaceConstants.HEALTH_CHECK)
  public ResponseEntity<BaseResponseModel> healthCheck() {
    log.info("Health Check for User Service Started");
    BaseResponseModel response = new BaseResponseModel();
    StatusMessage statusMessage = new StatusMessage();
    response.setStatus(MessageCodes.SUCCESS);
    statusMessage.setCode(MessageCodes.SUCCESS_MSG);
    statusMessage.setDescription(MessageCodes.HEALTH_CHECK_RES_DESC);
    response.setStatusMessage(statusMessage);
    log.info("Health Check for User Service Completed");
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @PostMapping(value = NameSpaceConstants.CREATE_USER_PROFILE)
  public ResponseEntity<UserProfileDTO> createUser(@RequestBody UserProfileDTO profileRequest) {
    log.info("Create user started - ");
    UserProfileDTO response = userService.createUser(profileRequest);
    log.info("Create user completed - ");
    return new ResponseEntity<>(response, HttpStatus.CREATED);
  }

  @PutMapping(value = NameSpaceConstants.UPDATE_USER_PROFILE)
  public ResponseEntity<UserProfileDTO> updateuser(
      @PathVariable("id") String id, @RequestBody UserProfileDTO profileRequest) throws Exception {
    log.info("Update user started - ");
    UserProfileDTO response = userService.updateUser(id, profileRequest);
    log.info("Update user completed - ");
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @GetMapping(value = NameSpaceConstants.GET_USER_PROFILE)
  public ResponseEntity<UserProfileDTO> getUserProfile(@PathVariable("id") String id) {
    log.info("Getting user Details started - ");
    UserProfileDTO response = userService.getUserProfile(id);
    log.info("Getting user Details completed - ");
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @DeleteMapping(value = NameSpaceConstants.DELETE_USER_PROFILE)
  public ResponseEntity<BaseResponseModel> deleteUser(@PathVariable("id") String id) {
    log.info("Delete user profile method started - ");
    BaseResponseModel customerResponse = userService.deleteUser(id);
    log.info("Delete user profile method completed - ");
    return new ResponseEntity<>(customerResponse, HttpStatus.OK);
  }

  @GetMapping(value = NameSpaceConstants.GET_ALL_USERS)
  public ResponseEntity<GetUsers> getUsers(
      @RequestParam(required = false, name = "firstName") String firstName,
      @RequestParam(required = false, name = "phoneNumber") String phoneNumber,
      @RequestParam(required = false, name = "lastName") String lastName,
      @RequestParam(required = false, name = "createdBy") String createdBy,
      @RequestParam(required = false, name = "currentPage", defaultValue = "1") int currentPage,
      @RequestParam(required = false, name = "perPage", defaultValue = "10") int perPage) {
    log.info("Getting all User Profiles started - ");
    GetUsers response =
        userService.getUsers(firstName, phoneNumber, lastName, createdBy, currentPage, perPage);
    log.info("Getting all User Profiles completed - ");
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}

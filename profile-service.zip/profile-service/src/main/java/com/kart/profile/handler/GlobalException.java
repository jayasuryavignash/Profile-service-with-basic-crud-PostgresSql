package com.kart.profile.handler;

import com.kart.profile.constants.MessageCodes;
import com.kart.profile.dto.response.BaseResponseModel;
import com.kart.profile.dto.response.StatusMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.IOException;

@Slf4j
@ControllerAdvice
public class GlobalException {

    /**
     * This method used to throw server internal error at global level
     *
     * @param e
     * @return
     * @throws Exception
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<BaseResponseModel> generalException(Exception e) {
        log.debug("Exception handler for handling Exception");
        log.error("Exception occured - ", e);
        BaseResponseModel model = new BaseResponseModel();
        model.setStatus(MessageCodes.INTERNAL_SERVER_ERROR);
        model.setStatusMessage(new StatusMessage(MessageCodes.INTERNAL_SERVER_ERROR_MSG,
                "Internal Server Error. Please try again later."));
        return new ResponseEntity<>(model, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * This method used to send bad request response error at global level
     *
     * @param e
     * @return
     * @throws IOException
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<BaseResponseModel> badRequest(MethodArgumentNotValidException e) {
        log.debug("Exception handler for handling MethodArgumentNotValidException");
        log.error("MethodArgumentNotValidException occured - ", e);
        BaseResponseModel model = new BaseResponseModel();
        model.setStatus(MessageCodes.BAD_REQUEST);
        model.setStatusMessage(new StatusMessage(MessageCodes.BAD_REQUEST_MSG, e.getMessage()));
        return new ResponseEntity<>(model, HttpStatus.OK);
    }

    /**
     * This method used to send custom exception error messages at global level
     *
     * @param e
     * @return
     * @throws Exception
     */
    @ExceptionHandler(CustomException.class)
    public ResponseEntity<BaseResponseModel> customException(CustomException e) {
        log.debug("Exception handler for handling CustomException");
        log.error("CustomException occured - ", e);
        BaseResponseModel model = new BaseResponseModel();
        if (e.getMessage().equalsIgnoreCase(MessageCodes.BAD_REQUEST)) {
            model.setStatus(MessageCodes.BAD_REQUEST);
            model.setStatusMessage(new StatusMessage(MessageCodes.BAD_REQUEST_MSG, MessageCodes.BAD_REQUEST_DESC));
            return new ResponseEntity<>(model, HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            model.setStatus(e.getStatus());
            model.setStatusMessage(new StatusMessage(e.getStatus(), e.getMessage()));
            return new ResponseEntity<>(model, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method used to send bad request response error at global level
     *
     * @param e
     * @return
     * @throws IOException
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<BaseResponseModel> handleIllegalArgumentException(IllegalArgumentException e) {
        log.debug("Exception handler for handling IllegalArgumentException");
        log.error("IllegalArgumentException occured - ", e);
        BaseResponseModel model = new BaseResponseModel();
        model.setStatus(MessageCodes.BAD_REQUEST);
        if (e.getMessage().equals("500")) {
            model.setStatusMessage(new StatusMessage(MessageCodes.BAD_REQUEST_MSG, MessageCodes.BAD_REQUEST_DESC));
        } else {
            model.setStatusMessage(new StatusMessage(MessageCodes.BAD_REQUEST_MSG,
                    null == e.getCause() ? e.getMessage() : e.getCause().getMessage()));
        }
        return new ResponseEntity<>(model, HttpStatus.OK);
    }

}

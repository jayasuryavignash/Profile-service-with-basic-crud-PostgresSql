package com.kart.profile.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "user_address")
public class Address implements Serializable {

	private static final long serialVersionUID = 8958321817658272862L;

	@Id
	@Column(name = "address_id")
	private String addressId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", referencedColumnName = "user_id")
	private UserProfile userProfile;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "status")
//	private Status status;

	@Column(name = "priority_order")
	private int priorityOrder;

	@Column(name = "address_type")
	private String addressType;

	@Column(name = "address_line1")
	private String addressLine1;
	
	@Column(name = "address_line2")
	private String addressLine2;

	@Column(name = "locality")
	private String locality;

	@Column(name = "landmark")
	private String landmark;

	@Column(name = "postal_code")
	private String postalCode;

	@Column(name = "phone_number")
	private String phoneNumber;

	@Column(name = "geo_location")
	private String geoLocation;

	@Column(name = "country")
	private String country;

	@Column(name = "state")
	private String state;

	@Column(name = "city")
	private String city;

	@Builder.Default
	@Column(name = "created_at")
	private Date createdAt = new Date();

	@Builder.Default
	@Column(name = "updated_at")
	private Date updatedAt = new Date();

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "updated_by")
	private String updatedBy;

}

package com.kart.profile.constants;

public class NameSpaceConstants {

  public static final String BASE_URL = "/api/v1.0";

  public static final String HEALTH_CHECK = "/profile-service-health";

  // Profile Services
  public static final String CREATE_USER_PROFILE = "/user";
  public static final String UPDATE_USER_PROFILE = "/user/{id}";
  public static final String GET_USER_PROFILE = "/user/{id}";
  public static final String DELETE_USER_PROFILE = "/user/{id}";
  public static final String GET_ALL_USERS = "/users";

}

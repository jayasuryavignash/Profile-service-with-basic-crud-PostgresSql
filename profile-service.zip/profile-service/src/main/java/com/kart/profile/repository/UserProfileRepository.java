package com.kart.profile.repository;

import com.kart.profile.model.UserProfile;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface UserProfileRepository extends CrudRepository<UserProfile, String> {

    @Query("select u from UserProfile u where u.phoneNumber=:phoneNumber")
    UserProfile findByPhoneNumber(@Param("phoneNumber") String phoneNumber);
}

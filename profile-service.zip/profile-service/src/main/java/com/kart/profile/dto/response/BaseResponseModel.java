package com.kart.profile.dto.response;

import com.kart.profile.dto.Meta;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class BaseResponseModel implements Serializable {

  private static final long serialVersionUID = 5846559455279367168L;
  private String userId;
  private String token;
  private String status;
  private int errorCode;
  private StatusMessage statusMessage;
  private Meta meta;

  @Override
  public String toString() {
    return "BaseResponseModel [status="
        + status
        + ", errorCode="
        + errorCode
        + ", statusMessage="
        + statusMessage
        + "]";
  }

  public String getStatus() {
    return this.status;
  }
}
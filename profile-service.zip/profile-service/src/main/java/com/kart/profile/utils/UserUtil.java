package com.kart.profile.utils;

import com.kart.profile.constants.MessageCodes;
import com.kart.profile.dao.UserDAO;
import com.kart.profile.dto.UserProfileDTO;
import com.kart.profile.model.UserProfile;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserUtil {

    private static UserDAO userDAO;

    public UserUtil(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public static void validateEmail(String emailId) {
        log.debug("Validating Email Id");
        if (CommonUtil.checkIsNullOrEmpty(emailId)) {
            log.error("Email Id is Mandatory");
            throw new IllegalArgumentException(MessageCodes.EMAIL_ID_MANDATORY);
        }
        if (!CommonUtil.checkEmail(emailId)) {
            log.error("Invalid Email Id");
            throw new IllegalArgumentException(MessageCodes.INVALID_EMAIL_ID);
        }
    }

    public static void validatePhoneNumber(String phone) {
        log.debug("Validating Phone Number");
        if (CommonUtil.checkIsNullOrEmpty(phone)) {
            log.error("Phone Number is Mandatory");
            throw new IllegalArgumentException(MessageCodes.PHONE_NUMBER_MANDATORY);
        }
        if (CommonUtil.isValidatePhone(phone)) {
            log.error("Invalid phone Number");
            throw new IllegalArgumentException(MessageCodes.INVALID_PHONE_NUMBER);
        }
    }

    public static boolean validate(UserProfileDTO profileRequest) {
        log.info("Validate create User profile request");
        validatePhoneNumber(profileRequest.getPhoneNumber());
        if (CommonUtil.checkIsNullOrEmpty(profileRequest.getFirstName())) {
            log.error("User first name is mandatory");
            throw new IllegalArgumentException(MessageCodes.MANDATORY_FIRST_NAME);
        }
        if (CommonUtil.checkIsNullOrEmpty(profileRequest.getLastName())) {
            log.error("User last name is mandatory");
            throw new IllegalArgumentException(MessageCodes.MANDATORY_LAST_NAME);
        }
        if (!CommonUtil.checkIsNullOrEmpty(profileRequest.getEmail())) {
            validateEmail(profileRequest.getEmail());
        }
        return Boolean.TRUE;
    }

    public static UserProfile validateUser(String id) {
        log.info("Validate user id - " + id);
        UserProfile userProfile = userDAO.getUser(id);
        if (null == userProfile) {
            log.error("Invalid user id is passed - " + id);
            throw new IllegalArgumentException(MessageCodes.INVALID_USER_ID);
        }
        return userProfile;
    }

    public UserProfile validateUserByPhoneNumber(String phoneNumber) {
        log.info("Validate user by phoneNumber - " + phoneNumber);
        UserProfile userProfile = userDAO.getUserProfileByPhoneNumber(phoneNumber);
        if (null == userProfile) {
            log.error("User does not exists");
            throw new IllegalArgumentException(MessageCodes.USER_DOES_NOT_EXISTS);
        }
        return userProfile;
    }
}

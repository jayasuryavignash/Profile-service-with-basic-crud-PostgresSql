package com.kart.profile.constants;

public class APPConstants {
  // External Service URL's
  public static final String COMMON_SERVICE_BASE_URL = "COMMON_SERVICE_BASE_URL";
}

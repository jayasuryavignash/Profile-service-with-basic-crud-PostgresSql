package com.kart.profile.utils;

import com.kart.profile.constants.MessageCodes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class CommonUtil {

	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
			Pattern.CASE_INSENSITIVE);
	private static final String CHAR_LOWER = "abcdefghijklmnopqrstuvwxyz";
	private static final String CHAR_UPPER = CHAR_LOWER.toUpperCase();
	private static final String NUMBER = "0123456789";

	private static final String DATA_FOR_RANDOM_STRING = CHAR_LOWER + CHAR_UPPER + NUMBER;
	private static SecureRandom random = new SecureRandom();
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

	public static String generateDigitUniqueId() {
		return UUID.randomUUID().toString().toUpperCase();
	}

	public static boolean checkIsNullOrEmpty(String data) {
		boolean emptyCheck = false;
		if (data == null || data.trim().isEmpty()) {
			emptyCheck = true;
		}
		return emptyCheck;
	}

	public static boolean checkIsNullOrFalse(Boolean data) {
		boolean emptyCheck = false;
		if (data == null || !data) {
			emptyCheck = true;
		}
		return emptyCheck;
	}

	public static boolean checkIsNullOrEmpty(Collection<?> data) {
		boolean emptyCheck = false;
		if (data == null || data.isEmpty()) {
			emptyCheck = true;
		}
		return emptyCheck;
	}

	public static boolean checkIsNullOrEmpty(Object[] data) {
		boolean emptyCheck = false;
		if (data == null || data.length == 0) {
			emptyCheck = true;
		}
		return emptyCheck;
	}

	public static boolean isValidatePhone(String phone) {
		if (phone.matches("\\d{10}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}")) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	public static boolean checkEmail(String email) {
		boolean emptyCheck = false;
		if (email != null) {
			Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email);
			emptyCheck = matcher.find();
		}
		return emptyCheck;
	}

	public static boolean checkIsNull(Object data) {
		boolean emptyCheck = false;
		if (data == null) {
			emptyCheck = true;
		}
		return emptyCheck;
	}

  public static Boolean checkIfNegative(Double balance) {
    boolean isNegative = false;
    if (balance < 0) {
      isNegative = true;
    }
    return isNegative;
  }

	public static String generateEightDigitUniqueId() {
		java.util.Random generator = new java.util.Random();
		generator.setSeed(System.currentTimeMillis());
		int i = generator.nextInt(10000000) % 10000000;
		java.text.DecimalFormat f = new java.text.DecimalFormat("00000000");
		return f.format(i);
	}

	public static String generateSixDigitUniqueId() {
		java.util.Random generator = new java.util.Random();
		generator.setSeed(System.currentTimeMillis());
		int i = generator.nextInt(100000) % 100000;
		java.text.DecimalFormat f = new java.text.DecimalFormat("000000");
		log.info("OTP ----------------------> " + f.format(i));
		return f.format(i);
	}

	public static String generateVerifyURL(String token, String host) {
		StringBuilder url = new StringBuilder(host);
		url.append("/v1/email_confirmation?confirmation_token=").append(token);
		return url.toString();
	}

	public static String generateResetPasswordURL(String token, String host) {
		StringBuilder url = new StringBuilder(host);
		url.append("/users/password-reset?reset_password_token=").append(token);
		return url.toString();
	}

	public static String getRandomString() {
		log.info("Generate a random string to generate encrypted token");
		int length = 8;
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			// 0-62 (exclusive), random returns 0-61
			int rndCharAt = random.nextInt(DATA_FOR_RANDOM_STRING.length());
			char rndChar = DATA_FOR_RANDOM_STRING.charAt(rndCharAt);
			sb.append(rndChar);
		}
		return sb.toString();
	}

	public static boolean checkPaginationParameters(int currentpage, int perPage) {
		boolean emptyCheck = true;
		if (currentpage <= 0 || perPage <= 0) {
			throw new IllegalArgumentException(MessageCodes.INVALID_PAGENO_OR_PAGESIZE);
		}
		return emptyCheck;
	}

	public static SimpleDateFormat getInputFormat() {
		SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
		return inputFormat;
	}

	public static SimpleDateFormat getOutputFormat() {
		SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
		return outputFormat;
	}

	public static File multipartToFile(MultipartFile avatar) throws IOException {
		File convFile = new File(avatar.getOriginalFilename());
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(avatar.getBytes());
		fos.close();
		return convFile;
	}

	public static Date formatInputStringDate(String dateString) {
		Date date = null;
		if (!checkIsNullOrEmpty(dateString))
			try {
				date = dateFormat.parse(dateString);
			} catch (ParseException e) {
				log.error("Error while parsing date", e);
			}
		return date;
	}

  public static String generateTenDigitUniqueId() {
    Long currentTimeMillis = System.currentTimeMillis() / 1000;
    return currentTimeMillis.toString().toString();
  }
}
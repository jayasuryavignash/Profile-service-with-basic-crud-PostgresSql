package com.kart.profile.dao.impl;

import com.kart.profile.dao.UserDAO;
import com.kart.profile.model.Address;
import com.kart.profile.model.UserProfile;
import com.kart.profile.repository.SearchUserRepository;
import com.kart.profile.repository.UserProfileRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class UserDAOImpl implements UserDAO {

  @Autowired private UserProfileRepository userProfileRepository;

  @Autowired private SearchUserRepository searchUserRepository;

  @Override
  public UserProfile save(UserProfile userProfile) {
    log.info("Save user profile to repository {}", userProfile);
    return userProfileRepository.save(userProfile);
  }

  @Override
  public UserProfile getUser(String id) {
    log.info("Get user profile from repository");
    return userProfileRepository.findById(id).orElse(null);
  }

  @Override
  public void save(Address profile) {}

  @Override
  public List<Address> getUserAddressByUserId(String id) {
    return null;
  }

  @Override
  public List<UserProfile> searchUser(
      Pageable pageable, String firstName, String phoneNumber, String lastName, String createdBy) {
    log.info(
        "get user with phoneNumber - "
            + phoneNumber
            + " email - "
            + lastName
            + " createdBy - "
            + createdBy
            + " firstName - "
            + firstName);
    return searchUserRepository.searchUser(pageable, firstName, phoneNumber, lastName, createdBy);
  }

  @Override
  public long countOfSearchUser(
      Pageable pageable, String firstName, String phoneNumber, String lastName, String createdBy) {
    log.info("Get user profile count based on the search ");
    return searchUserRepository.countUserBasedOnsearch(
        pageable, firstName, phoneNumber, lastName, createdBy);
  }

  @Override
  public UserProfile getUserProfileByPhoneNumber(String phoneNumber) {
    log.info("Get user profile by phone numer - " + phoneNumber);
    return userProfileRepository.findByPhoneNumber(phoneNumber);
  }
}
